const bodyParser = require('body-parser')
const cors = require('cors')
const express = require('express')
const mongoose = require('mongoose')
require('dotenv').config()
const routes = require('./routes/sessionRoutes')
const paymentRoutes = require('./routes/paymentRoutes')
const stationRoutes = require('./routes/stationRoutes')

const mongoString = process.env.DATABASE_URL
const port = process.env.PORT || '3000'

mongoose.connect(mongoString)
const database = mongoose.connection

database.on('error', (error) => {
  console.log(error)
})

database.once('connected', () => {
  console.log('Database Connected')
})
const app = express()

app.use(express.json())
app.use('/v1/sessions', routes)
app.use('/v1/payments', paymentRoutes)
app.use('/v1/stations', stationRoutes)

app.use(cors())

// Configuring body parser middleware
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.listen(port, () => {
  console.log(`Server Started at ${port}`)
})
